# Watt Cubed selective transfer v1

A standalone Rust implementation of the first material reaction law I recommend prototyping. It conserves element identities and transfers their membership between neighbouring blocks. This is a tested experimental material kernel, not an integrated game simulation.

Read `IMPLEMENTATION_GUIDE.md` for the complete law, rationale, arithmetic, scheduling, costs and limitations.

```sh
cargo test --offline
cargo test --offline --release
cargo run --offline --release --example counter_material
cargo run --offline --release --bin measure
```

There are no external dependencies. The code was compiled and tested with Rust 1.99.0 on x86-64 Linux. The release profile keeps arithmetic overflow checks enabled; the documented bounds also show that the supported inputs fit in `i32`.

## Integration

```rust
use watt_reaction::{react_once, Block};

let mut a = Block::new(&[[0, 0, 0, 0]]).unwrap();
let mut b = Block::new(&[[64, 64, 64, 64]]).unwrap();

if let Some(operation) = react_once(&mut a, &mut b) {
    // Commit both world cells together, then wake affected contacts.
    println!("{operation:?}");
}
```

Always orient A and B using the same physical contact key. `react_once` attempts one operation; it does not complete the entire cascade.

`Block` stores coordinates and a derived per-element internal-support cache. `Contact` adds exact transfer-score caches for one particular pair. Reuse a `Contact` only while no external operation has modified either block. Rebuilding a contact from current blocks is the safe default for a world with several interacting neighbours.

Call `Block::new` when a previously unseen configuration needs its derived cache. Do not reconstruct the block from raw coordinates before every contact. `react_once` and `Contact::blocks` already return valid updated caches.

## Contents

- `src/lib.rs`: law, cached state, and public API.
- `src/fit_table.rs`: authoritative integer fit table. Part of the law version.
- `src/tests.rs`: geometry, arithmetic, conservation, capacity, termination, permutation, swap-optimality and behavioural regression checks.
- `examples/counter_material.rs`: the four-transfer destructive exception.
- `src/bin/measure.rs`: reproducible native microbenchmark.
- `generate_fit_table.py`: standard-library-only Python script reproducing the committed table.
- `benchmark.json`: recorded measurements and execution context.
- `validation.txt` and `validation_summary.json`: recorded checks and scope.
- `fixtures/cohesive_holdout.bin`: the previously held-out 512 configurations, each four elements of four bytes; no header.
- `fixtures/cohesive_training.bin`: the earlier 256 search configurations in the same format; preserved for follow-up experiments, not hard-coded recipes.

The panels came from the earlier search: start with four uniformly sampled byte-coordinate elements, attempt 240 single-coordinate mutations per configuration, retain only improvements in summed internal fit. Training seed 907; holdout seed 20260915. They are synthetic cohesive materials, not a representative distribution of all possible configurations.

The revised law changes the earlier prototype's numerical representation, tie rule and full-capacity swap search. It is not bit-compatible with that prototype. Nothing in the core names or special-cases the example configurations.
