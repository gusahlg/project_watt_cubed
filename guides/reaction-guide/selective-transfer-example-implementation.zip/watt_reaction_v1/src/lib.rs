//! Selective transfer: an experimental, deterministic passive material law.
//! Integer scoring; no dependencies, heap allocation, random state or trig at runtime.
//! A and B must always use the caller's canonical physical contact ordering.

mod fit_table;

pub type Element = [u8; 4];
pub const CAPACITY: usize = 32;
pub const QUANTUM: i32 = 1 << 20;
pub const LAW_ID: &str = "watt-selective-transfer-v1";
const MAX_TOTAL: usize = 2 * CAPACITY;

/// Returns 4 * QUANTUM times the dimension-averaged pair fit, rounded per axis.
/// Negative means these constituents prefer separation; positive means grouping.
#[inline]
pub fn fit_raw(a: Element, b: Element) -> i32 {
    fit_table::FIT[a[0].wrapping_sub(b[0]) as usize]
        + fit_table::FIT[a[1].wrapping_sub(b[1]) as usize]
        + fit_table::FIT[a[2].wrapping_sub(b[2]) as usize]
        + fit_table::FIT[a[3].wrapping_sub(b[3]) as usize]
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TooManyElements(pub usize);

/// Array order is storage only. Duplicates are distinct occurrences of amount.
#[derive(Clone, Debug)]
pub struct Block {
    elements: [Element; CAPACITY],
    holding: [i32; CAPACITY],
    len: usize,
}

impl Default for Block {
    fn default() -> Self { Self { elements: [[0; 4]; CAPACITY], holding: [0; CAPACITY], len: 0 } }
}

impl Block {
    pub fn new(elements: &[Element]) -> Result<Self, TooManyElements> {
        if elements.len() > CAPACITY { return Err(TooManyElements(elements.len())); }
        let mut block = Self::default();
        block.len = elements.len();
        block.elements[..block.len].copy_from_slice(elements);
        for i in 0..block.len {
            for j in (i + 1)..block.len {
                let k = fit_raw(block.elements[i], block.elements[j]);
                block.holding[i] += k;
                block.holding[j] += k;
            }
        }
        Ok(block)
    }

    pub fn elements(&self) -> &[Element] { &self.elements[..self.len] }
    pub fn len(&self) -> usize { self.len }
    pub fn is_empty(&self) -> bool { self.len == 0 }

    /// Useful at an interning/save boundary. Sorting is not needed for reactions.
    pub fn canonicalize(&mut self) {
        // Keep each derived support attached to its element when storage moves.
        for i in 1..self.len {
            let (element, holding) = (self.elements[i], self.holding[i]);
            let mut j = i;
            while j > 0 && self.elements[j - 1] > element {
                self.elements[j] = self.elements[j - 1];
                self.holding[j] = self.holding[j - 1];
                j -= 1;
            }
            self.elements[j] = element;
            self.holding[j] = holding;
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Change {
    Transfer { from: u8, element: Element },
    Swap { from_a: Element, from_b: Element },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Operation {
    pub change: Change,
    /// Exact increase in the sum of fit_raw over within-block unordered pairs.
    pub raw_gain: i32,
    pub total_elements: u8,
}

impl Operation {
    /// Diagnostic conversion only. No floating-point result controls the law.
    pub fn normalized_gain(self) -> f64 {
        f64::from(self.raw_gain) / (4.0 * f64::from(QUANTUM) * f64::from(self.total_elements))
    }
}

#[derive(Clone, Copy)]
enum Move { Transfer(usize), Swap(usize, usize) }

#[derive(Clone, Copy)]
struct Decision { movement: Move, gain: i32 }

/// Scratch state for ONE two-block contact. It owns a snapshot, not world references.
/// Reuse it only while these are still the complete current contents of both blocks.
/// Rebuild after another neighbour, machine or player changes either block.
#[derive(Clone)]
pub struct Contact {
    elements: [Element; MAX_TOTAL],
    owner: [u8; MAX_TOTAL],
    gain: [i32; MAX_TOTAL],
    holding: [i32; MAX_TOTAL],
    len: usize,
    counts: [usize; 2],
}

impl Contact {
    pub fn new(a: &Block, b: &Block) -> Self {
        let mut state = Self {
            elements: [[0; 4]; MAX_TOTAL], owner: [0; MAX_TOTAL], gain: [0; MAX_TOTAL], holding: [0; MAX_TOTAL],
            len: a.len + b.len, counts: [a.len, b.len],
        };
        state.elements[..a.len].copy_from_slice(a.elements());
        state.elements[a.len..state.len].copy_from_slice(b.elements());
        state.owner[a.len..state.len].fill(1);
        state.holding[..a.len].copy_from_slice(&a.holding[..a.len]);
        state.holding[a.len..state.len].copy_from_slice(&b.holding[..b.len]);
        for i in 0..state.len {
            state.gain[i] = -state.holding[i];
        }
        // Internal support was cached on the configuration. Each cross-block
        // pair contributes its attraction once to each endpoint's score.
        for i in 0..a.len {
            for j in a.len..state.len {
                let k = fit_raw(state.elements[i], state.elements[j]);
                state.gain[i] += k;
                state.gain[j] += k;
            }
        }
        state
    }

    pub fn counts(&self) -> [usize; 2] { self.counts }

    /// The strict threshold is G > 1/32. Division is unnecessary:
    /// raw_gain > (4 * QUANTUM * total)/32 == total * (QUANTUM/8).
    fn threshold(&self) -> i32 { self.len as i32 * (QUANTUM / 8) }

    fn tie_key(&self, movement: Move) -> (u8, u32, u32) {
        match movement {
            Move::Transfer(i) => (0, u32::from(self.owner[i]), u32::from_be_bytes(self.elements[i])),
            Move::Swap(i, j) => (1, u32::from_be_bytes(self.elements[i]), u32::from_be_bytes(self.elements[j])),
        }
    }

    fn consider(&self, best: &mut Option<Decision>, candidate: Decision) {
        if candidate.gain <= self.threshold() { return; }
        let replace = match *best {
            None => true,
            Some(old) => candidate.gain > old.gain || (candidate.gain == old.gain
                && self.tie_key(candidate.movement) < self.tie_key(old.movement)),
        };
        if replace { *best = Some(candidate); }
    }

    fn choose(&self) -> Option<Decision> {
        let mut best = None;
        let capacity_limited = self.counts.contains(&CAPACITY);
        let mut leaders: [Option<usize>; 2] = [None, None];
        for i in 0..self.len {
            let side = self.owner[i] as usize;
            if capacity_limited && leaders[side].map_or(true, |old| self.gain[i] > self.gain[old]
                || (self.gain[i] == self.gain[old] && self.elements[i] < self.elements[old])) {
                leaders[side] = Some(i);
            }
            if self.counts[1 - side] < CAPACITY {
                self.consider(&mut best, Decision { movement: Move::Transfer(i), gain: self.gain[i] });
            }
        }
        // Capacity would otherwise prohibit some transfers. Check EVERY swap,
        // including constituents whose individual transfer scores are negative.
        // Below capacity on both sides, swaps are not part of this version's law.
        if capacity_limited {
            let (Some(lead_a), Some(lead_b)) = (leaders[0], leaders[1]) else { return best; };
            let gain = self.gain[lead_a] + self.gain[lead_b]
                - 2 * fit_raw(self.elements[lead_a], self.elements[lead_b]);
            self.consider(&mut best, Decision { movement: Move::Swap(lead_a, lead_b), gain });
            // Exact pruning, not a heuristic: fit_raw >= -8*QUANTUM, so the
            // best possible correction -2*fit_raw is at most 16*QUANTUM.
            let maximum_correction = 16 * QUANTUM;
            for i in 0..self.len {
                if self.owner[i] != 0 { continue; }
                let cutoff = best.map_or(self.threshold() + 1, |d| d.gain);
                if self.gain[i] + self.gain[lead_b] + maximum_correction < cutoff { continue; }
                for j in 0..self.len {
                    if self.owner[j] != 1 { continue; }
                    let cutoff = best.map_or(self.threshold() + 1, |d| d.gain);
                    if self.gain[i] + self.gain[j] + maximum_correction < cutoff { continue; }
                    let gain = self.gain[i] + self.gain[j] - 2 * fit_raw(self.elements[i], self.elements[j]);
                    self.consider(&mut best, Decision { movement: Move::Swap(i, j), gain });
                }
            }
        }
        best
    }

    fn describe(&self, decision: Decision) -> Operation {
        let change = match decision.movement {
            Move::Transfer(i) => Change::Transfer { from: self.owner[i], element: self.elements[i] },
            Move::Swap(i, j) => Change::Swap { from_a: self.elements[i], from_b: self.elements[j] },
        };
        Operation { change, raw_gain: decision.gain, total_elements: self.len as u8 }
    }

    pub fn peek(&self) -> Option<Operation> { self.choose().map(|d| self.describe(d)) }

    /// Commit at most one transfer or atomic swap. None means quiescent under
    /// this exact proposal rule, for these two exact configurations.
    pub fn step(&mut self) -> Option<Operation> {
        let decision = self.choose()?;
        let operation = self.describe(decision);
        match decision.movement {
            Move::Transfer(p) => {
                let from = self.owner[p];
                for i in 0..self.len {
                    if i == p { continue; }
                    let k = fit_raw(self.elements[i], self.elements[p]);
                    let holding_delta = if self.owner[i] == from { -k } else { k };
                    self.holding[i] += holding_delta;
                    self.gain[i] -= 2 * holding_delta;
                }
                self.holding[p] += self.gain[p];
                self.gain[p] = -self.gain[p];
                self.owner[p] = 1 - from;
                self.counts[from as usize] -= 1;
                self.counts[(1 - from) as usize] += 1;
            }
            Move::Swap(p, q) => {
                // p belongs to A, q to B. Apply both changes in one transaction.
                let pq = fit_raw(self.elements[p], self.elements[q]);
                for i in 0..self.len {
                    if i == p || i == q { continue; }
                    let difference = fit_raw(self.elements[i], self.elements[p])
                        - fit_raw(self.elements[i], self.elements[q]);
                    let holding_delta = if self.owner[i] == 0 { -difference } else { difference };
                    self.holding[i] += holding_delta;
                    self.gain[i] -= 2 * holding_delta;
                }
                self.holding[p] += self.gain[p] - pq;
                self.holding[q] += self.gain[q] - pq;
                self.gain[p] = -self.gain[p] + 2 * pq;
                self.gain[q] = -self.gain[q] + 2 * pq;
                self.owner[p] = 1;
                self.owner[q] = 0;
            }
        }
        Some(operation)
    }

    pub fn blocks(&self) -> [Block; 2] {
        let mut result = [Block::default(), Block::default()];
        for i in 0..self.len {
            let block = &mut result[self.owner[i] as usize];
            block.elements[block.len] = self.elements[i];
            block.holding[block.len] = self.holding[i];
            block.len += 1;
        }
        result
    }
}

/// Simple game integration entry point. No mutation when it returns None.
/// The caller must commit A and B together and invalidate their other contacts.
pub fn react_once(a: &mut Block, b: &mut Block) -> Option<Operation> {
    let mut contact = Contact::new(a, b);
    let operation = contact.step()?;
    let [next_a, next_b] = contact.blocks();
    *a = next_a;
    *b = next_b;
    Some(operation)
}

#[cfg(test)]
mod tests;
