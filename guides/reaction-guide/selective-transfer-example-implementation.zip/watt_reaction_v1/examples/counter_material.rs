use watt_reaction::{Block, Contact};

fn main() {
    let a = Block::new(&[[73,145,162,161],[71,77,157,208],[34,125,217,144],[8,85,210,206]]).unwrap();
    let e = Block::new(&[[83,135,211,195],[51,125,144,147],[11,72,167,145],[25,80,211,204]]).unwrap();
    let mut contact = Contact::new(&a, &e);
    println!("Initial counts: {:?}", contact.counts());
    while let Some(op) = contact.step() {
        println!("{:?}; gain {:.9}; counts {:?}", op.change, op.normalized_gain(), contact.counts());
    }
    println!("Quiescent; all eight original elements are conserved.");
}
